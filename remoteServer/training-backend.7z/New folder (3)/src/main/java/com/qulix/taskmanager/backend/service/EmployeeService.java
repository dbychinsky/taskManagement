package com.qulix.taskmanager.backend.service;

import java.util.NoSuchElementException;
import java.util.Objects;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import com.qulix.taskmanager.backend.model.Employee;
import com.qulix.taskmanager.backend.repository.EmployeeRepository;
import com.qulix.taskmanager.backend.repository.TaskRepository;

/**
 * Сервис для работы с исполнителями {@link Employee}.
 *
 * <p>Выполняет стандартные CRUD операции, используя базу данных.</p>
 *
 * @author Q-RAS
 */
@Service
public class EmployeeService {

    private final EmployeeRepository employeeRepository;
    private final TaskRepository taskRepository;

    public EmployeeService(EmployeeRepository employeeRepository, TaskRepository taskRepository) {
        this.employeeRepository = employeeRepository;
        this.taskRepository = taskRepository;
    }

    public Page<Employee> getAll(Pageable pageable) {
        return employeeRepository.findAll(pageable);
    }

    public Employee get(String id) {
        return employeeRepository.findById(id)
            .orElseThrow(NoSuchElementException::new);
    }

    public Employee save(Employee employee) {
        return employeeRepository.save(employee);
    }

    public void delete(String employeeId) {
        taskRepository.findAll().stream()
            .filter(task -> Objects.equals(employeeId, task.getEmployeeId()))
            .peek(task -> task.setEmployeeId(null))
            .forEach(taskRepository::save);

        employeeRepository.deleteById(employeeId);
    }
}
