package com.qulix.taskmanager.backend.service;

import java.util.NoSuchElementException;
import java.util.Objects;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import com.qulix.taskmanager.backend.model.Project;
import com.qulix.taskmanager.backend.repository.ProjectRepository;
import com.qulix.taskmanager.backend.repository.TaskRepository;

/**
 * Сервис для работы с проектами {@link Project}.
 *
 * <p>Выполняет стандартные CRUD операции, используя базу данных.</p>
 *
 * @author Q-RAS
 */
@Service
public class ProjectService {

    private final ProjectRepository projectRepository;
    private final TaskRepository taskRepository;

    public ProjectService(ProjectRepository projectRepository, TaskRepository taskRepository) {
        this.projectRepository = projectRepository;
        this.taskRepository = taskRepository;
    }

    public Page<Project> getAll(Pageable pageable) {
        return projectRepository.findAll(pageable);
    }

    public Project get(String id) {
        return projectRepository.findById(id)
            .orElseThrow(NoSuchElementException::new);
    }

    public Project save(Project project) {
        return projectRepository.save(project);
    }

    public void delete(String projectId) {
        taskRepository.findAll().stream()
            .filter(task -> Objects.equals(projectId, task.getProjectId()))
            .peek(task -> task.setProjectId(null))
            .forEach(taskRepository::save);

        projectRepository.deleteById(projectId);
    }
}
