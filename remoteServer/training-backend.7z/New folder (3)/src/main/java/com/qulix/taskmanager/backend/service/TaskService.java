package com.qulix.taskmanager.backend.service;

import java.util.List;
import java.util.NoSuchElementException;
import java.util.Objects;
import java.util.stream.Collectors;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import com.qulix.taskmanager.backend.model.Task;
import com.qulix.taskmanager.backend.repository.TaskRepository;

/**
 * Сервис для работы с задачами {@link Task}.
 *
 * <p>Выполняет стандартные CRUD операции, используя базу данных.</p>
 *
 * @author Q-RAS
 */
@Service
public class TaskService {

    private final TaskRepository repository;

    public TaskService(TaskRepository repository) {
        this.repository = repository;
    }

    public Page<Task> getAll(Pageable pageable) {
        return repository.findAll(pageable);
    }

    public Page<Task> getByProjectId(String projectId, Pageable pageable) {
        List<Task> tasks = repository.findAll().stream()
            .filter(task -> Objects.equals(projectId, task.getProjectId()))
            .collect(Collectors.toList());

        return new PageImpl<>(tasks, pageable, tasks.size());
    }

    public Task get(String id) {
        return repository.findById(id)
            .orElseThrow(NoSuchElementException::new);
    }

    public Task save(Task task) {
        return repository.save(task);
    }

    public void delete(String id) {
        repository.deleteById(id);
    }
}
