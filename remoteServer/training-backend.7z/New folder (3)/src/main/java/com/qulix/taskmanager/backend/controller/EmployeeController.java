package com.qulix.taskmanager.backend.controller;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.qulix.taskmanager.backend.model.Employee;
import com.qulix.taskmanager.backend.service.EmployeeService;

/**
 * Обработчик запросов, связанных с исполнителями {@link Employee}.
 *
 * <p>
 * Дает возможность обрабатывать следующие запросы:
 * <ul>
 *     <li>Получение всех исполнителей</li>
 *     <li>Получение исполнителя по идентификатору</li>
 *     <li>Создание исполнителя</li>
 *     <li>Изменение исполнителя</li>
 *     <li>Удаление исполнителя по идентификатору</li>
 * </ul>
 * </p>
 *
 * @author Q-DAY
 * @author Q-RAS
 */
@RestController
@RequestMapping("/api/employees")
public class EmployeeController {

    private EmployeeService employeeService;

    public EmployeeController(EmployeeService employeeService) {
        this.employeeService = employeeService;
    }

    @GetMapping
    public Page<Employee> getAll(@PageableDefault(size = 5) Pageable pageable) {
        return employeeService.getAll(pageable);
    }

    @GetMapping("{id}")
    public Employee get(@PathVariable("id") String id) {
        return employeeService.get(id);
    }

    @PostMapping
    public Employee create(@RequestBody Employee employee) {
        return employeeService.save(employee);
    }

    @PutMapping("{id}")
    public Employee update(@RequestBody Employee employee) {
        return employeeService.save(employee);
    }

    @DeleteMapping("{id}")
    public void delete(@PathVariable("id") String id) {
        employeeService.delete(id);
    }
}
