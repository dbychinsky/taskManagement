package com.qulix.taskmanager.backend.model;

import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

/**
 * Класс, описывающий сущность Задача.
 *
 * <p>Задача может принадлежать проекту {@link Project}, и на нее может быть назначен исполнитель {@link Employee}.</p>
 *
 * @author Q-RAS
 */
@Entity
public class Task {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private String id;

    @Column
    private String name;

    @Column(name = "execution_time")
    private Integer executionTime;

    @Column(name = "start_date")
    private LocalDate startDate;

    @Column(name = "finish_date")
    private LocalDate finishDate;

    @Column
    @Enumerated(EnumType.STRING)
    private TaskStatus status;

    @Column(name = "project_id")
    private String projectId;

    @Column(name = "employee_id")
    private String employeeId;

    public Task() {
    }

    public String getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public Integer getExecutionTime() {
        return executionTime;
    }

    public LocalDate getStartDate() {
        return startDate;
    }

    public LocalDate getFinishDate() {
        return finishDate;
    }

    public TaskStatus getStatus() {
        return status;
    }

    public String getProjectId() {
        return projectId;
    }

    public void setProjectId(String projectId) {
        this.projectId = projectId;
    }

    public String getEmployeeId() {
        return employeeId;
    }

    public void setEmployeeId(String employeeId) {
        this.employeeId = employeeId;
    }
}
