package com.qulix.taskmanager.backend.controller;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.qulix.taskmanager.backend.model.Project;
import com.qulix.taskmanager.backend.service.ProjectService;

/**
 * Обработчик запросов, связанных с проектами {@link Project}.
 *
 * <p>
 * Дает возможность обрабатывать следующие запросы:
 * <ul>
 *     <li>Получение всех проектов</li>
 *     <li>Получение проекта по идентификатору</li>
 *     <li>Создание проекта</li>
 *     <li>Изменение проекта</li>
 *     <li>Удаление проекта по идентификатору</li>
 * </ul>
 * </p>
 *
 * @author Q-DAY
 * @author Q-RAS
 */
@RestController
@RequestMapping("/api/projects")
public class ProjectController {

    private ProjectService projectService;

    public ProjectController(ProjectService projectService) {
        this.projectService = projectService;
    }

    @GetMapping
    public Page<Project> getAll(@PageableDefault(size = 5) Pageable pageable) {
        return projectService.getAll(pageable);
    }

    @GetMapping("{id}")
    public Project get(@PathVariable("id") String id) {
        return projectService.get(id);
    }

    @PostMapping
    public Project create(@RequestBody Project project) {
        return projectService.save(project);
    }

    @PutMapping("{id}")
    public Project update(@RequestBody Project project) {
        return projectService.save(project);
    }

    @DeleteMapping("{id}")
    public void delete(@PathVariable("id") String id) {
        projectService.delete(id);
    }

}
