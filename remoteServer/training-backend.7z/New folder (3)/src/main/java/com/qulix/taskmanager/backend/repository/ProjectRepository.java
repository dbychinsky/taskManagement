package com.qulix.taskmanager.backend.repository;

import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.stereotype.Repository;

import com.qulix.taskmanager.backend.model.Project;

/**
 * Репозиторий для работы с проектами {@link Project}.
 *
 * @author Q-RAS
 */
@Repository
public interface ProjectRepository extends PagingAndSortingRepository<Project, String> {

}
