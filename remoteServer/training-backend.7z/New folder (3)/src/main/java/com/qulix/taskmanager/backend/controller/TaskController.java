package com.qulix.taskmanager.backend.controller;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.qulix.taskmanager.backend.model.Task;
import com.qulix.taskmanager.backend.service.TaskService;

/**
 * Обработчик запросов, связанных с задачами {@link Task}.
 *
 * <p>
 * Дает возможность обрабатывать следующие запросы:
 * <ul>
 *     <li>Получение всех задач</li>
 *     <li>Получение задачи по идентификатору</li>
 *     <li>Получение задач по идентификатору проекта</li>
 *     <li>Создание задачи</li>
 *     <li>Изменение задачи</li>
 *     <li>Удаление задачи по идентификатору</li>
 * </ul>
 * </p>
 *
 * @author Q-DAY
 * @author Q-RAS
 */
@RestController
@RequestMapping("/api/tasks")
public class TaskController {

    private TaskService taskService;

    public TaskController(TaskService taskService) {
        this.taskService = taskService;
    }

    @GetMapping
    public Page<Task> getAll(@PageableDefault(size = 5) Pageable pageable) {
        return taskService.getAll(pageable);
    }

    @GetMapping(params = "projectId")
    public Page<Task> getByProjectId(@RequestParam("projectId") String projectId, @PageableDefault(size = 5) Pageable pageable) {
        return taskService.getByProjectId(projectId, pageable);
    }

    @GetMapping("{id}")
    public Task get(@PathVariable("id") String id) {
        return taskService.get(id);
    }

    @PostMapping
    public Task create(@RequestBody Task task) {
        return taskService.save(task);
    }

    @PutMapping("{id}")
    public Task update(@RequestBody Task task) {
        return taskService.save(task);
    }

    @DeleteMapping("{id}")
    public void delete(@PathVariable("id") String id) {
        taskService.delete(id);
    }
}
