package com.qulix.taskmanager.backend.repository;

import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.stereotype.Repository;

import com.qulix.taskmanager.backend.model.Employee;

/**
 * Репозиторий для работы с исполнителями {@link Employee}.
 *
 * @author Q-RAS
 */
@Repository
public interface EmployeeRepository extends PagingAndSortingRepository<Employee, String> {

}
