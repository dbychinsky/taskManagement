package com.qulix.taskmanager.backend.model;

/**
 * Перечисление, описывающее статусы выполнения задачи.
 *
 * @author Q-RAS
 */
public enum TaskStatus {

    NOT_STARTED("Не начата"),
    IN_PROGRESS("В процессе"),
    COMPLETED("Завершена"),
    POSTPONED("Отложена");

    private String title;

    TaskStatus(String title) {
        this.title = title;
    }

    public String getTitle() {
        return title;
    }
}
