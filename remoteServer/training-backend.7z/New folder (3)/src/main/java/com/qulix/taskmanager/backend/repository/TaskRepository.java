package com.qulix.taskmanager.backend.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.qulix.taskmanager.backend.model.Task;

/**
 * Репозиторий для работы с задачами {@link Task}.
 *
 * @author Q-RAS
 */
@Repository
public interface TaskRepository extends JpaRepository<Task, String> {

}
