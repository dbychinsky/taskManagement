INSERT INTO employee (last_name, first_name, middle_name, position) VALUES ('dubok', 'alex', 'seleznevich', 'angular-master');
INSERT INTO employee (last_name, first_name, middle_name, position) VALUES ('kapashilov', 'alex', 'kapashilovich', 'vue-master');
INSERT INTO employee (last_name, first_name, middle_name, position) VALUES ('bursevich', 'roma', 'vietnamovich', 'react-master');
INSERT INTO employee (last_name, first_name, middle_name, position) VALUES ('rymarchik', 'alex', 'rosbankovich', 'insert-data-master');
INSERT INTO employee (last_name, first_name, middle_name, position) VALUES ('limonchik', 'seha', 'jsovich', 'vaper');
INSERT INTO employee (last_name, first_name, position) VALUES ('noname', 'bez_otchestva', 'fullstack');

INSERT INTO project (name, short_name, description) VALUES ('rosbank', 'RBMB', 'some rosbank description');
INSERT INTO project (name, short_name, description) VALUES ('vietnam', 'VPB', 'some vietnam description');
INSERT INTO project (name, short_name, description) VALUES ('surgut', 'SNGB', 'some sngb description');
INSERT INTO project (name, short_name, description) VALUES ('trainingtask', 'TSKMNG', 'some trainingtask description');

INSERT INTO Task (name, execution_time, start_date, finish_date, status, project_id, employee_id)
VALUES ('Task for rosbank', 480, '2017-11-10', '2018-02-10', 'IN_PROGRESS', '1', '1');

INSERT INTO Task (name, execution_time, start_date, finish_date, status, project_id, employee_id)
VALUES ('Task for vietnam', 160, '2017-09-01', '2017-10-01', 'POSTPONED', '2', '2');

INSERT INTO Task (name, execution_time, start_date, finish_date, status, project_id, employee_id)
VALUES ('Another task for vietnam', 80, '2017-09-01', '2017-09-15', 'COMPLETED', '2', '3');

INSERT INTO Task (name, execution_time, start_date, finish_date, status, project_id, employee_id)
VALUES ('Task for sngb', 2920, '2016-12-12', '2017-12-12', 'IN_PROGRESS', '3', '2');

INSERT INTO Task (name, execution_time, start_date, finish_date, status, project_id, employee_id)
VALUES ('Another task for sngb', 1460, '2017-06-12', '2017-12-12', 'IN_PROGRESS', '3', '4');

INSERT INTO Task (name, execution_time, start_date, finish_date, status, project_id, employee_id)
VALUES ('Update description in readme file', 320, '2018-02-11', '2018-04-11', 'NOT_STARTED', '4', '1');
